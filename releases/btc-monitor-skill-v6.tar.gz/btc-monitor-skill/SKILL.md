# 🤖 BTC/ETH抄底监控 Skill

自动监控比特币和以太坊市场，识别抄底机会，每天早上8点发送深度分析报告到Discord。

## 功能特性

- ✅ 实时BTC和ETH市场数据分析
- ✅ 6个技术指标计算（RSI、MACD、布林带、成交量、支撑/阻力、恐慌指数）
- ✅ Kimi K2深度分析和投资建议
- ✅ 每天早上8点自动发送Discord报告
- ✅ 清晰的表格可视化 + 逻辑分析
- ✅ 信号强度评分（0-5）

## 快速开始

### 1. 安装Skill

```bash
# 克隆或复制到你的OpenClaw skills目录
cp -r btc-monitor-skill ~/.openclaw/skills/

# 或者用git
git clone <repo-url> ~/.openclaw/skills/btc-monitor-skill
```

### 2. 配置

编辑 `config.json`：

```json
{
  "discord": {
    "channelId": "YOUR_CHANNEL_ID",
    "userId": "YOUR_USER_ID"
  },
  "schedule": "0 8 * * *"
}
```

### 3. 启用Skill

```bash
openclaw skills enable btc-monitor
```

### 4. 验证

```bash
python3 scripts/monitor.py
```

## 配置说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `channelId` | Discord频道ID | 1475814722027655191 |
| `userId` | Discord用户ID（用于@提及） | 1168466656545222680 |
| `schedule` | Cron表达式 | `0 8 * * *` (每天8点) |

## 技术指标

### RSI (相对强弱指数)
- < 30: 超跌信号 🔴
- 30-70: 正常区间 🟡
- > 70: 超买信号 🟢

### MACD (移动平均收敛散离)
- 直方图为负: 下跌动能 🔴
- 直方图为正: 上升动能 🟢

### 成交量比
- < 0.3: 极度萎缩 🔴
- 0.3-0.7: 萎缩 🟡
- > 0.7: 正常 🟢

### 恐慌指数
- 0-25: 极度恐慌 🔴
- 25-50: 恐慌 🟡
- 50-75: 贪婪 🟢
- 75-100: 极度贪婪 🔴

## 信号强度

- **4-5/5**: 🔴 强抄底机会 → 建议分批建仓30-50%
- **3/5**: 🟡 中等机会 → 可轻仓参与或等待确认
- **0-2/5**: 🟢 弱信号 → 观望或小额试仓

## 数据源

- **币安API** - K线数据、成交量（免费公开）
- **CoinGecko API** - 市值、MVRV数据（免费）
- **Fear & Greed Index** - 市场情绪指数（免费）

## 文件结构

```
btc-monitor-skill/
├── SKILL.md                 # 本文件
├── config.json              # 配置文件
├── scripts/
│   ├── monitor.py          # 核心监控脚本
│   ├── install.sh          # 安装脚本
│   └── setup_cron.sh       # Cron设置脚本
├── docs/
│   ├── README.md           # 详细文档
│   └── TROUBLESHOOTING.md  # 故障排查
└── assets/
    └── icon.png            # Skill图标
```

## 使用示例

### 手动运行一次

```bash
python3 scripts/monitor.py
```

### 查看日志

```bash
tail -f logs/monitor.log
```

### 修改检查时间

编辑 `config.json` 的 `schedule` 字段：

```json
"schedule": "0 12 * * *"  // 改为每天中午12点
```

然后重新设置cron：

```bash
bash scripts/setup_cron.sh
```

## 常见问题

### Q: 报告没有发送到Discord
A: 检查：
1. Discord频道ID是否正确
2. Bot是否有发送消息权限
3. 网络连接是否正常

### Q: 数据获取失败
A: 检查：
1. 网络连接
2. API端点是否可用（币安、CoinGecko）
3. 查看日志文件

### Q: 如何修改分析指标
A: 编辑 `scripts/monitor.py` 中的阈值：
```python
thresholds = {
    "rsi": 30,           # RSI阈值
    "volumeRatio": 0.7,  # 成交量比阈值
    ...
}
```

## 自定义扩展

### 添加新币种

编辑 `scripts/monitor.py`，在 `main()` 函数中添加：

```python
sol_data = analyze_coin("SOLUSDT", "Solana (SOL)")
```

### 修改分析逻辑

编辑 `generate_analysis()` 函数来自定义分析文本。

### 集成其他数据源

在 `analyze_coin()` 函数中添加新的API调用。

## 性能

- 单次分析耗时: ~3-5秒
- 内存占用: ~50MB
- API调用: 3个（币安、CoinGecko、Fear & Greed）

## 安全性

- ✅ 不存储任何私钥或敏感信息
- ✅ 所有API调用都是公开端点
- ✅ Discord Token通过环境变量管理
- ✅ 日志不包含敏感数据

## 许可证

MIT License

## 支持

遇到问题？查看 `docs/TROUBLESHOOTING.md` 或提交Issue。

## 更新日志

### v3.0 (2026-02-24)
- ✅ 加入Kimi K2深度分析
- ✅ 改进表格可视化
- ✅ 添加投资建议
- ✅ 优化信号计算

### v2.0 (2026-02-24)
- ✅ 支持BTC和ETH同时监控
- ✅ 增加MACD和布林带指标
- ✅ 改进排版

### v1.0 (2026-02-24)
- ✅ 初始版本
- ✅ 基础监控功能
