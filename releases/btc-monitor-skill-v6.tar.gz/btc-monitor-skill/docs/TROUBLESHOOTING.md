# 故障排查指南

## 常见问题

### 1. 报告没有发送到Discord

**症状**: 脚本运行成功，但Discord频道没有收到消息

**排查步骤**:
- 检查config.json中的channelId和userId是否正确
- 确保Bot有发送消息权限
- 验证Discord Token是否有效

**解决方案**:
- 重新生成Discord Bot Token
- 确认Bot已加入服务器
- 检查频道权限设置

### 2. 数据获取失败

**症状**: 脚本报错 "无法获取K线数据"

**排查步骤**:
- 检查网络连接
- 测试API端点是否可用
- 查看详细错误日志

**解决方案**:
- 检查防火墙设置
- 币安API可能被限流，稍后重试
- 检查API端点是否可用

### 3. Cron任务未运行

**症状**: 到了设定时间但没有自动执行

**排查步骤**:
- 检查crontab是否设置: crontab -l
- 检查cron服务是否运行
- 查看cron日志

**解决方案**:
- 重新运行: bash scripts/setup_cron.sh
- 手动添加到crontab: crontab -e

### 4. Python依赖缺失

**症状**: ModuleNotFoundError: No module named 'requests'

**解决方案**:
- 安装requests: pip install requests
- 或使用: python3 -m pip install requests

### 5. 权限错误

**症状**: Permission denied

**解决方案**:
- 修复脚本权限: chmod +x scripts/*.sh
- 创建日志目录: mkdir -p logs

### 6. 时区问题

**症状**: Cron任务在错误的时间运行

**解决方案**:
- 检查系统时区: timedatectl
- 设置时区: sudo timedatectl set-timezone Asia/Shanghai

## 常用命令

查看日志:
  tail -f logs/monitor.log

手动运行:
  python3 scripts/monitor.py

检查cron:
  crontab -l

重新安装:
  bash scripts/install.sh

重新设置cron:
  bash scripts/setup_cron.sh

查看配置:
  cat config.json

测试API:
  curl https://api.binance.com/api/v3/ping
