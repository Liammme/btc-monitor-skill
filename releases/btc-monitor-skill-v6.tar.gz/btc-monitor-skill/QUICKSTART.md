# 🚀 快速启动 (5分钟)

## 1️⃣ 安装 (1分钟)

```bash
cp -r btc-monitor-skill ~/.openclaw/skills/
cd ~/.openclaw/skills/btc-monitor-skill
bash scripts/install.sh
```

## 2️⃣ 配置Discord (2分钟)

编辑 `config.json`：

```bash
nano config.json
```

填入你的Discord信息：
- `channelId`: 右键频道 → 复制频道ID
- `userId`: 右键用户名 → 复制用户ID

## 3️⃣ 启动 (1分钟)

```bash
# 设置自动运行
bash scripts/setup_cron.sh

# 测试一次
python3 scripts/monitor.py
```

## 4️⃣ 完成 ✅

明天早上8点会自动发送第一条报告到Discord！

---

## 常用命令

```bash
# 查看日志
tail -f logs/monitor.log

# 手动运行
python3 scripts/monitor.py

# 修改时间
nano config.json  # 改schedule字段
bash scripts/setup_cron.sh

# 查看cron
crontab -l
```

## 遇到问题？

查看 `docs/TROUBLESHOOTING.md`

---

**就这么简单！** 🎉
