# 安装指南

## 系统要求

- Python 3.7+
- Linux/macOS/Windows (with WSL)
- 网络连接
- Discord账户和服务器

## 安装步骤

### 1. 克隆或下载

```bash
# 方式A: Git克隆
git clone https://github.com/yourusername/btc-monitor-skill.git ~/.openclaw/skills/btc-monitor-skill

# 方式B: 直接复制
cp -r btc-monitor-skill ~/.openclaw/skills/
```

### 2. 进入目录

```bash
cd ~/.openclaw/skills/btc-monitor-skill
```

### 3. 运行安装脚本

```bash
bash scripts/install.sh
```

### 4. 配置Discord

#### 获取Discord信息

**频道ID:**
1. 在Discord中启用开发者模式 (用户设置 → 高级 → 开发者模式)
2. 右键点击频道 → 复制频道ID

**用户ID:**
1. 右键点击你的用户名 → 复制用户ID

**Bot Token:**
1. 去 https://discord.com/developers/applications
2. 点击 "New Application"
3. 给应用命名
4. 左边菜单 → "Bot" → "Add Bot"
5. 点击 "Copy" 复制Token

#### 编辑配置

```bash
nano config.json
```

修改以下内容：

```json
{
  "discord": {
    "channelId": "YOUR_CHANNEL_ID",
    "userId": "YOUR_USER_ID"
  },
  "schedule": "0 8 * * *"
}
```

### 5. 设置Cron定时任务

```bash
bash scripts/setup_cron.sh
```

### 6. 测试

```bash
python3 scripts/monitor.py
```

应该看到类似的输出：

```
🔍 正在分析BTC和ETH...

╔════════════════════════════════════════════════════════════════╗
║           🤖 加密货币抄底监控报告 (Kimi K2分析)               ║
...
```

## 验证安装

### 检查Cron任务

```bash
crontab -l | grep btc-monitor
```

应该看到：

```
0 8 * * * cd ~/.openclaw/skills/btc-monitor-skill && python3 scripts/monitor.py >> logs/monitor.log 2>&1
```

### 查看日志

```bash
tail -f logs/monitor.log
```

### 手动测试

```bash
python3 scripts/monitor.py
```

## 常见安装问题

### Python版本过低

```bash
# 检查Python版本
python3 --version

# 需要3.7+，如果版本过低，升级Python
```

### requests库缺失

```bash
# 安装requests
pip install requests

# 或
python3 -m pip install requests
```

### 权限错误

```bash
# 修复脚本权限
chmod +x scripts/*.sh

# 创建日志目录
mkdir -p logs
chmod 755 logs
```

### Cron不工作

```bash
# 检查cron服务
sudo service cron status

# 重新设置cron
bash scripts/setup_cron.sh

# 查看cron日志
grep CRON /var/log/syslog
```

## 卸载

```bash
# 移除cron任务
crontab -e
# 删除btc-monitor相关的行

# 删除Skill目录
rm -rf ~/.openclaw/skills/btc-monitor-skill
```

## 下一步

1. 等待明天早上8点的第一条报告
2. 查看 `docs/README.md` 了解更多功能
3. 查看 `docs/TROUBLESHOOTING.md` 解决问题
4. 根据需要自定义配置

## 获取帮助

- 查看文档: `docs/README.md`
- 故障排查: `docs/TROUBLESHOOTING.md`
- 查看日志: `tail -f logs/monitor.log`
- 提交Issue: GitHub Issues

---

**安装完成！祝你抄底成功！** 🚀
