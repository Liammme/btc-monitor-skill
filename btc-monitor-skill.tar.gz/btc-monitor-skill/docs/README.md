# BTC/ETH抄底监控 Skill - 完整指南

## 概述

这是一个OpenClaw Skill，用于自动监控比特币和以太坊市场，识别抄底机会。

**核心功能：**
- 每天早上8点自动分析BTC和ETH
- 使用Kimi K2模型进行深度分析
- 发送详细报告到Discord
- 提供投资建议和风险提示

## 安装步骤

### 1. 克隆或复制Skill

```bash
# 方式A: 直接复制
cp -r btc-monitor-skill ~/.openclaw/skills/

# 方式B: Git克隆
git clone <repo-url> ~/.openclaw/skills/btc-monitor-skill
```

### 2. 运行安装脚本

```bash
cd ~/.openclaw/skills/btc-monitor-skill
bash scripts/install.sh
```

### 3. 配置Discord

编辑 `config.json`：

```json
{
  "discord": {
    "token": "YOUR_BOT_TOKEN",
    "channelId": "YOUR_CHANNEL_ID",
    "userId": "YOUR_USER_ID"
  },
  "binance": {
    "symbol": "BTCUSDT",
    "interval": "1w"
  },
  "schedule": "0 8 * * *"
}
```

**获取Discord信息：**

- **channelId**: 在Discord中右键点击频道 → 复制频道ID
- **userId**: 右键点击你的用户名 → 复制用户ID
- **token**: 去 https://discord.com/developers/applications 创建Bot并获取Token

### 4. 设置Cron定时任务

```bash
bash scripts/setup_cron.sh
```

### 5. 测试

```bash
python3 scripts/monitor.py
```

应该看到类似的输出：

```
🔍 正在分析BTC和ETH...

╔════════════════════════════════════════════════════════════════╗
║           🤖 加密货币抄底监控报告 (Kimi K2分析)               ║
...
```

## 配置详解

### config.json

```json
{
  "discord": {
    "token": "Bot Token用于发送消息",
    "channelId": "目标Discord频道ID",
    "userId": "用户ID（用于@提及）"
  },
  "binance": {
    "symbol": "交易对（BTCUSDT/ETHUSDT等）",
    "interval": "K线周期（1w=周线）"
  },
  "thresholds": {
    "rsi": 30,              // RSI超跌阈值
    "volumeRatio": 0.7,     // 成交量比阈值
    "mvrv": 1.0,            // MVRV比率阈值
    "fearGreedIndex": 75,   // 恐慌指数阈值
    "ltdSupplyRatio": 0.55  // LTH供应占比阈���
  },
  "weights": {
    "rsi": 0.2,             // RSI权重
    "volume": 0.15,         // 成交量权重
    "mvrv": 0.25,           // MVRV权重
    "sentiment": 0.2,       // 情绪权重
    "minerCost": 0.1,       // 矿机成本权重
    "lth": 0.1              // LTH权重
  },
  "schedule": "0 8 * * *"   // Cron表达式
}
```

### Cron表达式

```
┌───────────── 分钟 (0 - 59)
│ ┌───────────── 小时 (0 - 23)
│ │ ┌───────────── 日�� (1 - 31)
│ │ │ ┌───────────── 月份 (1 - 12)
│ │ │ │ ┌───────────── 星期 (0 - 6) (0=周日)
│ │ │ │ │
│ │ │ │ │
* * * * *

示例：
0 8 * * *     # 每天早上8点
0 */6 * * *   # 每6小时
0 8,14 * * *  # 每天8点和14点
```

## 使用指南

### 手动运行

```bash
python3 ~/.openclaw/skills/btc-monitor-skill/scripts/monitor.py
```

### 查看日志

```bash
tail -f ~/.openclaw/skills/btc-monitor-skill/logs/monitor.log
```

### 修改检查时间

编辑 `config.json` 的 `schedule` 字段，然后重新运行：

```bash
bash scripts/setup_cron.sh
```

### 添加新币种

编辑 `scripts/monitor.py`，在 `main()` 函数中添加：

```python
sol_data = analyze_coin("SOLUSDT", "Solana (SOL)")
report = format_report(btc_data, eth_data, sol_data)
```

## 输出示例

```
╔════════════════════════════════════════════════════════════════╗
║           🤖 加密货币抄底监控报告 (Kimi K2分析)               ║
║           2026-02-24 20:52:24                          ║
╚════════════════════════════════════════════════════════════════╝

┌─ Bitcoin (BTC) ─────────────────────────────────────────────────────┐
│
│  💰 价格: $63,010.73  (-6.85%)
│
│  📊 技术指标:
│     • RSI(14)        🔴 23.17  超跌
│     • MACD           🔴 -13680.3858
│     • 直方图         -1368.0386
│     • 成交量比       🔴 0.23  萎缩
│
│  🎯 支撑/阻力:
│     • 支撑位: $63,010.73
│     • 阻力位: $114,559.40
│
│  😨 市场情绪:
│     • 恐慌指数       🟢 8  极度恐慌
│
│  🎲 信号强度: 4/5
│  📈 评级: 🔴 强抄底
│
└──────────────────────────────────────────────────────────────┘

📊 Bitcoin (BTC) 深度分析:
  • RSI超跌(23.2)，典型抄底信号，建议分批建仓
  • MACD直方图为负，下跌动能仍存，需等待反转信号
  • 成交量极度萎缩(0.23x)，恐慌抛售后的枯竭现象，反弹在即
  • 周线跌幅-6.85%，短期承压明显
  • 恐慌指数8(极度恐慌)，市场情绪已触底，反弹信号强

  💡 建议: 强抄底机会，建议分批建仓30-50%
```

## 技术指标说明

### RSI (相对强弱指数)
衡量价格超买/超卖程度。

- **< 30**: 超跌，可能反弹 🔴
- **30-70**: 正常区间 🟡
- **> 70**: 超买，可能回调 🟢

### MACD (移动平均收敛散离)
判断趋势和动能。

- **直方图为负**: 下跌动能 🔴
- **直方图为正**: 上升动能 🟢

### 成交量比
对比最近成交量与30日均量。

- **< 0.3**: 极度萎缩 🔴
- **0.3-0.7**: 萎缩 🟡
- **> 0.7**: 正常 🟢

### 恐慌指数
市场情绪指标（0-100）。

- **0-25**: 极度恐慌 🔴
- **25-50**: 恐慌 🟡
- **50-75**: 贪婪 🟢
- **75-100**: 极度贪婪 🔴

## 信号强度评分

系统会计算0-5的信号强度：

- **4-5/5**: 🔴 **强抄底机会**
  - 建议: 分批建仓30-50%
  - 风险: 中等

- **3/5**: 🟡 **中等机会**
  - 建议: 轻仓参与或等待确认
  - 风险: 较高

- **0-2/5**: 🟢 **弱信号**
  - 建议: 观望或小额试仓
  - 风险: 高

## 数据源

所有数据来自免费公开API：

- **币安API** - K线、成交量数据
- **CoinGecko API** - 市值、MVRV数据
- **Alternative.me** - 恐慌指数

## 性能指标

- **执行时间**: 3-5秒
- **内存占用**: ~50MB
- **API调用**: 3个
- **网络带宽**: ~1MB

## 安全性

✅ **安全特性：**
- 不存储私钥或敏感信息
- 所有API调用都是公开端点
- Discord Token通过config.json管理
- 日志不包含敏感数据

⚠️ **建议：**
- 定期更新Discord Token
- 不要在公开频道分享config.json
- 定期检查日志文件

## 故障排查

详见 `TROUBLESHOOTING.md`

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！

## 更新

定期检查更新：

```bash
cd ~/.openclaw/skills/btc-monitor-skill
git pull
```
