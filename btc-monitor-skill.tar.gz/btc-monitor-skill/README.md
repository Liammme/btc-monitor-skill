# 🤖 BTC/ETH抄底监控 Skill

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.7+](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)

自动监控比特币和以太坊市场，识别抄底机会，每天早上8点发送深度分析报告到Discord。

## ✨ 功能特性

- ✅ 实时BTC和ETH市场数据分析
- ✅ 6个技术指标计算（RSI、MACD、布林带、成交量、支撑/阻力、恐慌指数）
- ✅ Kimi K2深度分析和投资建议
- ✅ 每天早上8点自动发送Discord报告
- ✅ 清晰的表格可视化 + 逻辑分析
- ✅ 信号强度评分（0-5）

## 🚀 快速开始

### 1. 安装

```bash
# 克隆或复制到OpenClaw skills目录
cp -r btc-monitor-skill ~/.openclaw/skills/

# 运行安装脚本
cd ~/.openclaw/skills/btc-monitor-skill
bash scripts/install.sh
```

### 2. 配置

编辑 `config.json`：

```json
{
  "discord": {
    "channelId": "YOUR_CHANNEL_ID",
    "userId": "YOUR_USER_ID"
  },
  "schedule": "0 8 * * *"
}
```

### 3. 设置Cron

```bash
bash scripts/setup_cron.sh
```

### 4. 测试

```bash
python3 scripts/monitor.py
```

## 📊 技术指标

| 指标 | 阈值 | 含义 |
|------|------|------|
| RSI | < 30 | 超跌信号 🔴 |
| MACD | 直方图为负 | 下跌动能 🔴 |
| 成交量 | < 0.7倍 | 成交量萎缩 🔴 |
| 恐慌指数 | > 70 | 市场恐慌 🔴 |
| 支撑位 | 接近 | 反弹信号 🔴 |
| LTH占比 | > 55% | 长期持有者增加 🔴 |

## 🎯 信号强度

- **4-5/5**: 🔴 强抄底机会 → 建议分批建仓30-50%
- **3/5**: 🟡 中等机会 → 可轻仓参与或等待确认
- **0-2/5**: 🟢 弱信号 → 观望或小额试仓

## 📁 项目结构

```
btc-monitor-skill/
├── SKILL.md                 # Skill文档
├── README.md                # 本文件
├── package.json             # 包配置
├── config.json              # 配置文件
├── scripts/
│   ├── monitor.py          # 核心监控脚本
│   ├── install.sh          # 安装脚本
│   └── setup_cron.sh       # Cron设置脚本
├── docs/
│   ├── README.md           # 详细文档
│   └── TROUBLESHOOTING.md  # 故障排查
└── logs/                    # 日志目录
```

## 🔧 配置说明

### config.json

```json
{
  "discord": {
    "channelId": "Discord频道ID",
    "userId": "用户ID（用于@提及）"
  },
  "binance": {
    "symbol": "BTCUSDT",
    "interval": "1w"
  },
  "schedule": "0 8 * * *"
}
```

### Cron表达式

```
0 8 * * *     # 每天早上8点
0 */6 * * *   # 每6小时
0 8,14 * * *  # 每天8点和14点
```

## 📖 使用指南

### 手动运行

```bash
python3 scripts/monitor.py
```

### 查看日志

```bash
tail -f logs/monitor.log
```

### 修改检查时间

编辑 `config.json` 的 `schedule` 字段，然后：

```bash
bash scripts/setup_cron.sh
```

### 添加新币种

编辑 `scripts/monitor.py`，在 `main()` 函数中添加：

```python
sol_data = analyze_coin("SOLUSDT", "Solana (SOL)")
```

## 📊 输出示例

```
╔════════════════════════════════════════════════════════════════╗
║           🤖 加密货币抄底监控报告 (Kimi K2分析)               ║
║           2026-02-24 20:52:24                          ║
╚════════════════════════════════════════════════════════════════╝

┌─ Bitcoin (BTC) ─────────────────────────────────────────────────────┐
│
│  💰 价格: $63,010.73  (-6.85%)
│
│  📊 技术指标:
│     • RSI(14)        🔴 23.17  超跌
│     • MACD           🔴 -13680.3858
│     • 直方图         -1368.0386
│     • 成交量比       🔴 0.23  萎缩
│
│  🎯 支撑/阻力:
│     • 支撑位: $63,010.73
│     • 阻力位: $114,559.40
│
│  😨 市场情绪:
│     • 恐慌指数       🟢 8  极度恐慌
│
│  🎲 信号强度: 4/5
│  📈 评级: 🔴 强抄底
│
└──────────────────────────────────────────────────────────────┘

📊 Bitcoin (BTC) 深度分析:
  • RSI超跌(23.2)，典型抄底信号，建议分批建仓
  • MACD直方图为负，下跌动能仍存，需等待反转信号
  • 成交量极度萎缩(0.23x)，恐慌抛售后的枯竭现象，反弹在即
  • 周线跌幅-6.85%，短期承压明显
  • 恐慌指数8(极度恐慌)，市场情绪已触底，反弹信号强

  💡 建议: 强抄底机会，建议分批建仓30-50%
```

## 🌐 数据源

所有数据来自免费公开API：

- **币安API** - K线、成交量数据
- **CoinGecko API** - 市值、MVRV数据
- **Alternative.me** - 恐慌指数

## ⚡ 性能

- **执行时间**: 3-5秒
- **内存占用**: ~50MB
- **API调用**: 3个
- **网络带宽**: ~1MB

## 🔐 安全性

✅ **安全特性：**
- 不存储私钥或敏感信息
- 所有API调用都是公开端点
- Discord Token通过config.json管理
- 日志不包含敏感数据

⚠️ **建议：**
- 定期更新Discord Token
- 不要在公开频道分享config.json
- 定期检查日志文件

## 🐛 故障排查

详见 `docs/TROUBLESHOOTING.md`

常见问题：
- 报告没有发送到Discord
- 数据获取失败
- Cron任务未运行
- Python依赖缺失

## 📝 许可证

MIT License - 详见 LICENSE 文件

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📞 支持

遇到问题？
1. 查看 `docs/TROUBLESHOOTING.md`
2. 检查日志文件 `logs/monitor.log`
3. 提交Issue并附加日志

## 🔄 更新

定期检查更新：

```bash
cd ~/.openclaw/skills/btc-monitor-skill
git pull
```

## 📚 相关资源

- [OpenClaw文档](https://docs.openclaw.ai)
- [币安API文档](https://binance-docs.github.io/apidocs/)
- [CoinGecko API文档](https://www.coingecko.com/api/documentations/v3)
- [Fear & Greed Index](https://alternative.me/crypto/fear-and-greed-index/)

---

**Made with ❤️ for crypto traders**
