#!/bin/bash

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_FILE="$SKILL_DIR/config.json"

# 读取schedule配置
SCHEDULE=$(grep -o '"schedule": "[^"]*"' "$CONFIG_FILE" | cut -d'"' -f4)

if [ -z "$SCHEDULE" ]; then
    SCHEDULE="0 8 * * *"
fi

# 创建cron任务
CRON_JOB="$SCHEDULE cd $SKILL_DIR && python3 scripts/monitor.py >> logs/monitor.log 2>&1"

(crontab -l 2>/dev/null | grep -v "btc-monitor"; echo "$CRON_JOB") | crontab -

echo "✅ Cron任务已设置"
echo "⏰ 时间表: $SCHEDULE"
echo "📝 日志: $SKILL_DIR/logs/monitor.log"
