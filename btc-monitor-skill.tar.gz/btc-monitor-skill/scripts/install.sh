#!/bin/bash

echo "🚀 安装BTC监控Skill..."

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# 检查Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3未安装"
    exit 1
fi

# 检查依赖
echo "📦 检查依赖..."
python3 -c "import requests" 2>/dev/null || {
    echo "⚠️ 缺少requests库，尝试安装..."
    python3 -m pip install requests 2>/dev/null || echo "⚠️ 无法自动安装，请手动运行: pip install requests"
}

# 创建日志目录
mkdir -p "$SKILL_DIR/logs"

echo "✅ 安装完成"
echo "📝 下一步: 编辑 config.json 配置Discord信息"
echo "🧪 测试: python3 $SKILL_DIR/scripts/monitor.py"
